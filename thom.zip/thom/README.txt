# Project Structure and File Explanations

This project is structured into several Python modules to enhance organization, maintainability, and readability. Below is an explanation of each key file:

## `config.py`

* **Purpose:** Centralizes all configuration variables for the application.
* **Key Contents:**
    * API Keys (e.g., `GOOGLE_API_KEY`)
    * Neo4j Database Connection Details (`NEO4J_URI`, `NEO4J_USER`, `NEO4J_PASSWORD`)
    * Application Authentication Credentials (`VALID_USERNAME`, `VALID_PASSWORD`) - *Note: For production, these should not be hardcoded.*
    * AI Model Configuration (e.g., `GEMINI_MODEL_NAME`)
    * Neo4j Graph Data Science (GDS) graph names (e.g., `PRODUCT_COPURCHASE_GRAPH`, `CUSTOMER_SIMILARITY_GRAPH`)
    * Agent settings (e.g., `MAX_CYPHER_ATTEMPTS`)
* **Security Note:** This file is designed to read sensitive values (like API keys and passwords) from environment variables to avoid hardcoding secrets directly into the source code. Ensure that environment variables are properly set in your deployment environment.
* **Dependencies:** None (provides configuration to other modules).

## `neo4j_utils.py`

* **Purpose:** Handles all direct interactions with the Neo4j database.
* **Key Functions:**
    * `get_driver()`: Establishes and caches the connection (driver) to the Neo4j database using credentials from `config.py`. Includes basic connection verification and error handling. It's decorated with `@st.cache_resource` to reuse the connection across Streamlit reruns efficiently.
    * `run_cypher(query)`: Takes a Cypher query string as input, executes it against the database using a session obtained from the driver, and returns the results. It handles potential `CypherSyntaxError` and other execution errors, returning either a list of result dictionaries or an error message string.
    * `close_driver()`: (Optional) Provides a function to explicitly close the Neo4j driver connection, potentially used for cleanup.
* **Dependencies:** `config.py` (for database credentials), `streamlit` (for caching), `neo4j` (for database interaction).

## `agents.py`

* **Purpose:** Contains the logic for the AI agents that interact with the Google Generative AI (Gemini) API.
* **Key Functions:**
    * `analyze_question(question)`: Takes the user's natural language question, constructs a detailed prompt including the database schema (nodes, properties, relationships), and sends it to the Gemini model (`config.GEMINI_MODEL_NAME`). It asks the AI to identify relevant schema elements and suggest a query approach, returning the AI's analysis as text. Includes error handling for the API call.
    * `generate_cypher_and_execute(question, analysis)`: Takes the user's question and the analysis from `analyze_question`. It constructs another prompt for the Gemini model, providing the question, analysis, sample data values, schema details, pre-existing GDS graph names (`config.PRODUCT_COPURCHASE_GRAPH`, `config.CUSTOMER_SIMILARITY_GRAPH`), formatting instructions, and an example query. It asks the AI to generate *only* the Cypher query. It then attempts to execute this query using `neo4j_utils.run_cypher`. If execution fails (due to syntax errors or other issues reported by `run_cypher`), it implements a retry loop (up to `config.MAX_CYPHER_ATTEMPTS`), feeding the error back to the AI to request a correction. It returns the final generated Cypher query (or the last attempted one) and the result (either a Pandas DataFrame, a "No results found." message, or an error message string).
* **Dependencies:** `config.py` (for API key, model name, graph names, max attempts), `neo4j_utils.py` (to execute queries), `google.generativeai`, `pandas`.

## `auth.py`

* **Purpose:** Manages user authentication for accessing the application.
* **Key Functions:**
    * `authenticate(username, password)`: Performs a basic check against predefined valid credentials stored in `config.py`. *This is a placeholder and should be replaced with a secure authentication mechanism (e.g., database lookup with hashed passwords) for any real-world application.*
    * `login_screen()`: Uses Streamlit components (`st.text_input`, `st.button`) to display a login form. It calls `authenticate` when the login button is clicked and updates the Streamlit session state (`st.session_state`) to track login status (`logged_in`) and username.
* **Dependencies:** `config.py` (for credentials), `streamlit`.

## `app.py`

* **Purpose:** The main entry point and user interface (UI) logic for the Streamlit application. It orchestrates the interactions between the user, the UI, the authentication module, the AI agents, and the Neo4j utilities.
* **Key Functions/Logic:**
    * Sets the Streamlit page configuration (`st.set_page_config`).
    * Initializes and manages Streamlit session state variables (`st.session_state`) for login status, username, and chat message history.
    * Displays the `auth.login_screen()` if the user is not logged in.
    * If logged in, displays the main chat interface:
        * Shows a welcome message and an optional logout button.
        * Renders the chat history stored in `st.session_state.messages`.
        * Provides a chat input box (`st.chat_input`) for the user to ask questions.
    * Handles the workflow when a user submits a question:
        1.  Adds the user's message to the chat history.
        2.  Calls `agents.analyze_question()` and displays the analysis.
        3.  Calls `agents.generate_cypher_and_execute()` with the question and analysis.
        4.  Displays the generated Cypher query (using `st.code`).
        5.  Displays the results from the query execution: either a Pandas DataFrame (using `st.dataframe`), an informational message (e.g., "No results found."), or an error message (using `st.error`).
        6.  Appends the assistant's responses (analysis, query, results/errors) to the chat history.
* **Dependencies:** `streamlit`, `pandas`, `config.py`, `neo4j_utils.py`, `agents.py`, `auth.py`.